const dameLasnotasYa = __dirname;

module.exports = {
    dameLasnotasYa
}